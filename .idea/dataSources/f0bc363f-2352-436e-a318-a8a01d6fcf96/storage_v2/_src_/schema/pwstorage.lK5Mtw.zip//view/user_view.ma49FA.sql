create view user_view as
select `pwstorage`.`user`.`user_id` AS `user_id`, `pwstorage`.`user`.`user_name` AS `user_name`
from `pwstorage`.`user`;

